from flask import Flask, request, render_template
import pickle
import numpy as np

app = Flask(__name__)

# Load trained model and scaler
try:
    model = pickle.load(open('insurance_model.pkl', 'rb'))
except FileNotFoundError:
    # fallback to svm_model.pkl if present
    model = pickle.load(open('regressor.pkl', 'rb'))
scaler = pickle.load(open('scaler.pkl', 'rb'))

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/predict', methods=['POST'])
def predict():

    age = int(request.form['age'])
    sex = int(request.form['sex'])
    bmi = float(request.form['bmi'])
    children = int(request.form['children'])
    smoker = int(request.form['smoker'])    # yes=1, no=0
    region = int(request.form['region'])    # 0:Northeast,1:Northwest,2:Southeast,3:Southwest

    # Map to feature names expected by the model (one-hot encoding)
    sex_male = 1 if sex == 1 else 0
    smoker_yes = 1 if smoker == 1 else 0
    region_northwest = 1 if region == 1 else 0
    region_southeast = 1 if region == 2 else 0
    region_southwest = 1 if region == 3 else 0

    # Prepare input in the required order:
    # [age, bmi, children, sex_male, smoker_yes, region_northwest, region_southeast, region_southwest]
    input_data = np.array([[age, bmi, children, sex_male, smoker_yes,
                            region_northwest, region_southeast, region_southwest]])

    # Scale input
    input_data = scaler.transform(input_data)

    # Predict insurance cost
    prediction = model.predict(input_data)[0]

    prediction = round(prediction, 2)

    return render_template(
        'index.html',
        prediction=f"Estimated Insurance Cost: ₹ {prediction}"
    )

if __name__ == '__main__':
    app.run(debug=True)